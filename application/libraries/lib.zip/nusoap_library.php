<?php
class Nusoap_library
{
   function Nusoap_library()
   {
       require_once('lib/nusoap'.EXT);
   }
}

?>